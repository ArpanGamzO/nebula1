import { useState } from "react";
import { motion } from "framer-motion";
import { 
  Shield, Sword, Gift, Wrench, Ticket, 
  LayoutDashboard, Settings, Users, Activity,
  Bell, LogOut, ChevronRight, Search
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";

export default function Dashboard() {
  const [activeTab, setActiveTab] = useState("overview");

  return (
    <div className="min-h-screen bg-background flex overflow-hidden">
      {/* Sidebar */}
      <aside className="w-64 bg-card border-r border-border hidden md:flex flex-col">
        <div className="p-6">
          <h2 className="font-display text-2xl font-bold tracking-widest text-white neon-text">
            N E B U L Δ
          </h2>
        </div>
        
        <div className="px-4 mb-6">
          <div className="bg-white/5 rounded-lg p-3 border border-white/10 flex items-center gap-3">
            <Avatar className="h-10 w-10 border border-white/20">
              <AvatarImage src="https://github.com/shadcn.png" />
              <AvatarFallback>SV</AvatarFallback>
            </Avatar>
            <div className="overflow-hidden">
              <p className="text-sm font-medium text-white truncate">My Super Server</p>
              <p className="text-xs text-white/50">Owner</p>
            </div>
            <ChevronRight className="w-4 h-4 text-white/30 ml-auto" />
          </div>
        </div>

        <nav className="flex-1 px-4 space-y-2">
          <SidebarItem icon={<LayoutDashboard />} label="Overview" active={activeTab === "overview"} onClick={() => setActiveTab("overview")} />
          <SidebarItem icon={<Shield />} label="Antinuke" active={activeTab === "antinuke"} onClick={() => setActiveTab("antinuke")} />
          <SidebarItem icon={<Sword />} label="Moderation" active={activeTab === "moderation"} onClick={() => setActiveTab("moderation")} />
          <SidebarItem icon={<Ticket />} label="Tickets" active={activeTab === "tickets"} onClick={() => setActiveTab("tickets")} />
          <SidebarItem icon={<Gift />} label="Giveaways" active={activeTab === "giveaways"} onClick={() => setActiveTab("giveaways")} />
          <SidebarItem icon={<Settings />} label="Settings" active={activeTab === "settings"} onClick={() => setActiveTab("settings")} />
        </nav>

        <div className="p-4 border-t border-white/10">
          <Button variant="ghost" className="w-full justify-start text-red-400 hover:text-red-300 hover:bg-red-500/10">
            <LogOut className="w-4 h-4 mr-2" />
            Logout
          </Button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 overflow-y-auto bg-background/50">
        <header className="h-16 border-b border-white/5 bg-black/20 backdrop-blur-sm flex items-center justify-between px-8 sticky top-0 z-10">
          <div className="text-white/50 text-sm breadcrumbs">
            Dashboard / <span className="text-white font-medium capitalize">{activeTab}</span>
          </div>
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" className="text-white/70 hover:text-white">
              <Bell className="w-5 h-5" />
            </Button>
            <Avatar className="h-8 w-8 border border-white/20">
              <AvatarFallback className="bg-white/10 text-white text-xs">US</AvatarFallback>
            </Avatar>
          </div>
        </header>

        <div className="p-8 max-w-7xl mx-auto">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3 }}
          >
            {activeTab === "overview" && <OverviewTab />}
            {activeTab === "antinuke" && <AntinukeTab />}
            {activeTab === "moderation" && <ModerationTab />}
            {/* Placeholders for other tabs */}
            {["tickets", "giveaways", "settings"].includes(activeTab) && (
              <div className="flex flex-col items-center justify-center py-20 text-center">
                <Wrench className="w-16 h-16 text-white/20 mb-4" />
                <h3 className="text-2xl font-bold text-white mb-2">Under Construction</h3>
                <p className="text-white/50">This module is currently being updated.</p>
              </div>
            )}
          </motion.div>
        </div>
      </main>
    </div>
  );
}

function SidebarItem({ icon, label, active, onClick }: { icon: any, label: string, active: boolean, onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-all duration-200
        ${active 
          ? "bg-white text-black shadow-[0_0_15px_rgba(255,255,255,0.4)]" 
          : "text-white/60 hover:text-white hover:bg-white/5"
        }`}
    >
      {icon}
      {label}
    </button>
  );
}

function OverviewTab() {
  return (
    <div className="space-y-8">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatsCard title="Total Members" value="12,453" icon={<Users className="text-blue-400" />} />
        <StatsCard title="Active Tickets" value="42" icon={<Ticket className="text-green-400" />} />
        <StatsCard title="Server Level" value="Level 3" icon={<Activity className="text-purple-400" />} />
        <StatsCard title="Commands Used" value="1.2M" icon={<Sword className="text-orange-400" />} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-2 bg-black/40 border-white/10 backdrop-blur-md">
          <CardHeader>
            <CardTitle className="text-white">Recent Activity</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {[1, 2, 3, 4].map((i) => (
                <div key={i} className="flex items-center gap-4 p-3 rounded-lg hover:bg-white/5 transition-colors border border-transparent hover:border-white/5">
                  <div className="w-2 h-2 rounded-full bg-green-500 shadow-[0_0_8px_rgba(34,197,94,0.5)]" />
                  <p className="text-sm text-white/80">
                    <span className="font-bold text-white">User_{i}</span> was banned by <span className="font-bold text-white">AutoMod</span>
                  </p>
                  <span className="text-xs text-white/30 ml-auto">2m ago</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card className="bg-black/40 border-white/10 backdrop-blur-md">
          <CardHeader>
            <CardTitle className="text-white">Quick Actions</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <Button className="w-full bg-white text-black hover:bg-white/90">Lockdown Server</Button>
            <Button variant="outline" className="w-full border-white/20 text-white hover:bg-white/10">Clear Chat</Button>
            <Button variant="outline" className="w-full border-white/20 text-white hover:bg-white/10">Create Announcement</Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function StatsCard({ title, value, icon }: { title: string, value: string, icon: any }) {
  return (
    <Card className="bg-black/40 border-white/10 backdrop-blur-md hover:border-white/30 transition-all duration-300 group">
      <CardContent className="p-6 flex items-center justify-between">
        <div>
          <p className="text-sm font-medium text-white/50 mb-1">{title}</p>
          <h3 className="text-3xl font-bold text-white group-hover:text-glow transition-all">{value}</h3>
        </div>
        <div className="p-3 rounded-xl bg-white/5 border border-white/10 group-hover:scale-110 transition-transform duration-300">
          {icon}
        </div>
      </CardContent>
    </Card>
  );
}

function AntinukeTab() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-white">Antinuke Settings</h2>
          <p className="text-white/50">Configure protection levels for your server.</p>
        </div>
        <Button className="bg-white text-black">Save Changes</Button>
      </div>

      <Card className="bg-black/40 border-white/10 backdrop-blur-md">
        <CardContent className="p-6 space-y-6">
          <SettingToggle 
            title="Anti-Ban" 
            description="Prevents unauthorized members from banning users." 
            enabled={true} 
          />
          <Separator className="bg-white/10" />
          <SettingToggle 
            title="Anti-Kick" 
            description="Prevents unauthorized members from kicking users." 
            enabled={true} 
          />
          <Separator className="bg-white/10" />
          <SettingToggle 
            title="Anti-Role Delete" 
            description="Prevents deletion of roles." 
            enabled={false} 
          />
          <Separator className="bg-white/10" />
          <SettingToggle 
            title="Anti-Channel Create" 
            description="Prevents creation of new channels." 
            enabled={true} 
          />
        </CardContent>
      </Card>
    </div>
  );
}

function ModerationTab() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-white">Moderation Logs</h2>
          <p className="text-white/50">View recent moderation actions.</p>
        </div>
        <div className="flex gap-2">
          <Input placeholder="Search user..." className="bg-black/20 border-white/10 text-white w-64" />
          <Button variant="outline" className="border-white/20 text-white"><Search className="w-4 h-4" /></Button>
        </div>
      </div>

      <Card className="bg-black/40 border-white/10 backdrop-blur-md">
        <CardContent className="p-0">
          <div className="w-full">
            <div className="grid grid-cols-5 gap-4 p-4 border-b border-white/10 text-sm font-medium text-white/50">
              <div className="col-span-2">User</div>
              <div>Action</div>
              <div>Moderator</div>
              <div className="text-right">Date</div>
            </div>
            {[1, 2, 3, 4, 5].map((i) => (
              <div key={i} className="grid grid-cols-5 gap-4 p-4 border-b border-white/5 items-center hover:bg-white/5 transition-colors">
                <div className="col-span-2 flex items-center gap-3">
                  <Avatar className="h-8 w-8">
                    <AvatarFallback>U{i}</AvatarFallback>
                  </Avatar>
                  <span className="text-white font-medium">User_{i}</span>
                </div>
                <div>
                  <span className="px-2 py-1 rounded text-xs font-medium bg-red-500/20 text-red-400 border border-red-500/30">BAN</span>
                </div>
                <div className="text-white/70">Admin_Bot</div>
                <div className="text-right text-white/30 text-sm">2 hours ago</div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

function SettingToggle({ title, description, enabled }: { title: string, description: string, enabled: boolean }) {
  const [state, setState] = useState(enabled);
  return (
    <div className="flex items-center justify-between">
      <div>
        <h4 className="text-white font-medium mb-1">{title}</h4>
        <p className="text-sm text-white/50">{description}</p>
      </div>
      <Switch 
        checked={state} 
        onCheckedChange={setState}
        className="data-[state=checked]:bg-white data-[state=unchecked]:bg-white/10"
      />
    </div>
  );
}
