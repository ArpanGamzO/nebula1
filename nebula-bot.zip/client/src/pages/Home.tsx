import { motion } from "framer-motion";
import { Shield, Sword, Gift, Wrench, Ticket, ArrowRight, ExternalLink, Server } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Navbar } from "@/components/layout/Navbar";
import background from "@assets/generated_images/subtle_dark_nebula_background.png";

const container = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1
    }
  }
};

const item = {
  hidden: { opacity: 0, y: 20 },
  show: { opacity: 1, y: 0 }
};

export default function Home() {
  return (
    <div className="min-h-screen bg-background text-foreground overflow-hidden">
      <Navbar />
      
      {/* Background Overlay */}
      <div 
        className="fixed inset-0 z-[-1] opacity-30 pointer-events-none"
        style={{
          backgroundImage: `url(${background})`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
        }}
      />

      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center pt-16">
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-background/50 to-background pointer-events-none" />
        
        <div className="container mx-auto px-4 text-center relative z-10">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
          >
            <h1 className="font-display text-6xl md:text-8xl font-black tracking-widest mb-6 neon-text select-none">
              N E B U L Δ ™
            </h1>
            <p className="text-xl md:text-2xl text-white/70 max-w-2xl mx-auto mb-10 font-light">
              The Ultimate Multi-Purpose Protection & Utility Bot.
              <br />
              <span className="text-white/40 text-base mt-2 block">Secure. Fast. Reliable.</span>
            </p>
            
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                <a href="https://discord.com/oauth2/authorize?client_id=1434857888081248287" target="_blank" rel="noopener noreferrer">
                  <Button size="lg" className="bg-white text-black hover:bg-white/90 font-bold px-8 py-6 text-lg shadow-[0_0_20px_rgba(255,255,255,0.3)] border-none">
                    Invite Bot <ArrowRight className="ml-2 w-5 h-5" />
                  </Button>
                </a>
              </motion.div>
              
              <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                <Button size="lg" variant="outline" className="glass border-white/20 text-white px-8 py-6 text-lg hover:bg-white/10">
                  Join Support <ExternalLink className="ml-2 w-5 h-5" />
                </Button>
              </motion.div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-32 relative">
        <div className="container mx-auto px-4">
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="font-display text-4xl font-bold text-center mb-16 text-white text-glow"
          >
            SYSTEM MODULES
          </motion.h2>

          <motion.div 
            variants={container}
            initial="hidden"
            whileInView="show"
            viewport={{ once: true }}
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
          >
            {features.map((feature, index) => (
              <motion.div key={index} variants={item}>
                <div className="group relative h-full p-1 rounded-2xl bg-gradient-to-b from-white/10 to-transparent hover:from-white/30 transition-all duration-500">
                  <div className="absolute inset-0 rounded-2xl bg-white/5 blur-xl opacity-0 group-hover:opacity-30 transition-opacity duration-500" />
                  <div className="relative h-full p-8 rounded-xl bg-black/40 backdrop-blur-xl border border-white/10 group-hover:border-white/30 transition-colors">
                    <div className="mb-6 inline-block p-4 rounded-lg bg-white/5 border border-white/10 group-hover:scale-110 group-hover:bg-white/10 transition-all duration-300">
                      {feature.icon}
                    </div>
                    <h3 className="font-display text-xl font-bold mb-3 text-white group-hover:text-glow transition-all">
                      {feature.title}
                    </h3>
                    <p className="text-white/60 leading-relaxed">
                      {feature.description}
                    </p>
                  </div>
                </div>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 border-t border-white/5 bg-black/50 backdrop-blur-lg">
        <div className="container mx-auto px-4 text-center">
          <p className="font-display font-bold text-xl tracking-widest mb-4 text-white/30">N E B U L Δ ™</p>
          <p className="text-white/40 text-sm">
            © {new Date().getFullYear()} All rights reserved.
          </p>
        </div>
      </footer>
    </div>
  );
}

const features = [
  {
    icon: <Shield className="w-8 h-8 text-white" />,
    title: "Antinuke System",
    description: "Advanced protection against unauthorized server changes, raids, and nukers. Keeps your community safe 24/7."
  },
  {
    icon: <Sword className="w-8 h-8 text-white" />,
    title: "Moderation",
    description: "Comprehensive moderation suite with Kick, Ban, Mute, Warn, and Lockdown capabilities. Complete control."
  },
  {
    icon: <Gift className="w-8 h-8 text-white" />,
    title: "Giveaways",
    description: "Host engaging giveaways with auto-reroll, multi-winner support, and scheduled start/end times."
  },
  {
    icon: <Wrench className="w-8 h-8 text-white" />,
    title: "Utility Tools",
    description: "Essential utilities including User Info, Server Info, Avatar lookup, Weather data, and more."
  },
  {
    icon: <Ticket className="w-8 h-8 text-white" />,
    title: "Ticket System",
    description: "Professional support ticket system with custom categories, transcripts, and staff controls."
  },
  {
    icon: <Server className="w-8 h-8 text-white" />,
    title: "Server Management",
    description: "Tools to manage roles, channels, and permissions efficiently with bulk actions."
  }
];
